package org.nonage.domain;

import lombok.Data;

@Data
public class AdminVO {
    private String id;
    private String pwd;
    private String name;
    private String phone;
}
