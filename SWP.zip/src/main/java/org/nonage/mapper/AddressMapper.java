package org.nonage.mapper;

public interface AddressMapper {
}
