package org.nonage.mapper;

public interface AdminMapper {
}
