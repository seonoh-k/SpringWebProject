package org.nonage.mapper;

public interface CartMapper {
}
