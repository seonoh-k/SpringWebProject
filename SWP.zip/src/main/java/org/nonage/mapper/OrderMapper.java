package org.nonage.mapper;

public interface OrderMapper {
}
