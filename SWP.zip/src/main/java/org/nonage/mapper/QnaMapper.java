package org.nonage.mapper;

public interface QnaMapper {
}
