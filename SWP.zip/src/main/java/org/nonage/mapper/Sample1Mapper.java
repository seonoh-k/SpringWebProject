package org.nonage.mapper;

import org.nonage.domain.ProductVO;

import java.util.List;

public interface Sample1Mapper {

    public List<ProductVO> get();
}
