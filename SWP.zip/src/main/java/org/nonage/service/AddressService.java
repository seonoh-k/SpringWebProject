package org.nonage.service;

public interface AddressService {
}
