package org.nonage.service;

public interface CartService {
}
