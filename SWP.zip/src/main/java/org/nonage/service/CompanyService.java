package org.nonage.service;

public interface CompanyService {
}
