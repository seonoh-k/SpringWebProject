package org.nonage.service;

public interface OrderService {
}
