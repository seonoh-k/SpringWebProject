package org.nonage.service;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
@Log4j
public class OrderServiceImpl implements OrderService{
}
