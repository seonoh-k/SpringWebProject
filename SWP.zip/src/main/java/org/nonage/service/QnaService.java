package org.nonage.service;

public interface QnaService {
}
